import cv2
import numpy as np
import time


# cap = cv2.VideoCapture(0)

cap = cv2.VideoCapture(1)


if not cap.isOpened():
    print("Error: Couldn't open the IP camera.")
    exit()

start_time = time.time()
fps = 0
frame_cnt = 0

while(True):
    ret, frame = cap.read()

    #FPS
    frame_cnt +=1
    if time.time() - start_time >= 1:
        elapsed_time = time.time() - start_time
        fps = frame_cnt/elapsed_time
        frame_cnt = 0
        start_time = time.time() 
        # print(f'FPS: {fps:.2f}')

    # # 4. brightest
    # gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    # min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(gray)
    # cv2.circle(frame, max_loc, 10, (0, 255, 0), 2)

    # 5. reddest
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    low_red = np.array([0, 100, 100])
    hi_red = np.array([10, 255, 255])
    mask = cv2.inRange(hsv, low_red, hi_red)
    red_spot = cv2.minMaxLoc(mask)
    cv2.circle(frame, red_spot[3], 10, (0, 0, 255), 2)

    # # 6. brightest með double for
    # rows, cols = gray.shape
    # brightest_loc = (0, 0)
    # max_intensity = 0

    # for i in range(rows):
    #     for j in range(cols):
    #         intensity = gray[i, j]
    #         if intensity > max_intensity:
    #             max_intensity = intensity
    #             brightest_loc = (j, i)

    # cv2.circle(frame, brightest_loc, 10, (0, 255, 0), 2)


    cv2.putText(frame, f'FPS: {fps:.2f}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 0, 0), 2)
    cv2.imshow('frame', frame)


    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
# import cv2

# cap = cv2.VideoCapture(0)

# while(True):
#     ret, frame = cap.read()
#     gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

#     cv2.imshow('frame',gray)
#     if cv2.waitKey(1) & 0xFF == ord('q'):
#         break

# cap.release()
# cv2.destroyAllWindows()